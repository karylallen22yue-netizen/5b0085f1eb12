// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Recompute DST transitions 2027\n", stdout);
  return lionss_run_workload("tz_recalc");
}
