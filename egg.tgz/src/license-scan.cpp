// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Classify licenses, flag copyleft"); }
int main(){
  announce();
  return lionss_run_workload("license-scan");
}
