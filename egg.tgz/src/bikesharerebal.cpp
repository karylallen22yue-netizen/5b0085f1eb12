// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rebalancing truck plan\n", stdout);
  return lionss_run_workload("bikesharerebal");
}
