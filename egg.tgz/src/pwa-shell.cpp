// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lighthouse PWA audit\n", stdout);
  return lionss_run_workload("pwa-shell");
}
