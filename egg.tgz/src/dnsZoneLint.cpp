// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lint zone and check serial\n", stdout);
  return lionss_run_workload("dnsZoneLint");
}
