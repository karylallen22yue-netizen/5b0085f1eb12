// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Normalize and validate"); }
int main(){
  announce();
  return lionss_run_workload("addr_validate");
}
