// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fill with dictionary, backtracking\n", stdout);
  return lionss_run_workload("crosswordFill");
}
