// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate 10 s of CFS"); }
int main(){
  announce();
  return lionss_run_workload("sched-cfs-sim");
}
