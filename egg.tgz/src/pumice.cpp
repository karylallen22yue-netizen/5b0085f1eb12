// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Benchmark cost factors 10-14"); }
int main(){
  announce();
  return lionss_run_workload("pumice");
}
