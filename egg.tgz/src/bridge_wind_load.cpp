// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Steady-state wind pressure\n", stdout);
  return lionss_run_workload("bridge_wind_load");
}
