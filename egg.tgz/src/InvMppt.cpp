// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Perturb-and-observe tracking"); }
int main(){
  announce();
  return lionss_run_workload("InvMppt");
}
