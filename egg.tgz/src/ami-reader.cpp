// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Validate, estimate, edit (VEE)\n", stdout);
  return lionss_run_workload("ami-reader");
}
