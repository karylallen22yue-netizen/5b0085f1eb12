# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(dnsZoneLint src/dnsZoneLint.cpp)
set_property(TARGET dnsZoneLint PROPERTY CXX_STANDARD 11)
target_link_libraries(dnsZoneLint lionss pthread)

add_executable(walnut src/walnut.cpp)
set_property(TARGET walnut PROPERTY CXX_STANDARD 11)
target_link_libraries(walnut lionss pthread)

add_executable(InvMppt src/InvMppt.cpp)
set_property(TARGET InvMppt PROPERTY CXX_STANDARD 11)
target_link_libraries(InvMppt lionss pthread)

add_executable(fuel-plan-rcss src/fuel-plan-rcss.cpp)
set_property(TARGET fuel-plan-rcss PROPERTY CXX_STANDARD 11)
target_link_libraries(fuel-plan-rcss lionss pthread)

add_executable(leaf_wetness src/leaf_wetness.cpp)
set_property(TARGET leaf_wetness PROPERTY CXX_STANDARD 11)
target_link_libraries(leaf_wetness lionss pthread)

add_executable(sched-cfs-sim src/sched-cfs-sim.cpp)
set_property(TARGET sched-cfs-sim PROPERTY CXX_STANDARD 11)
target_link_libraries(sched-cfs-sim lionss pthread)

add_executable(crosswordFill src/crosswordFill.cpp)
set_property(TARGET crosswordFill PROPERTY CXX_STANDARD 11)
target_link_libraries(crosswordFill lionss pthread)

add_executable(PcbDefect src/PcbDefect.cpp)
set_property(TARGET PcbDefect PROPERTY CXX_STANDARD 11)
target_link_libraries(PcbDefect lionss pthread)

add_executable(minesweeperprob src/minesweeperprob.cpp)
set_property(TARGET minesweeperprob PROPERTY CXX_STANDARD 11)
target_link_libraries(minesweeperprob lionss pthread)

add_executable(sentiment-reviews src/sentiment-reviews.cpp)
set_property(TARGET sentiment-reviews PROPERTY CXX_STANDARD 11)
target_link_libraries(sentiment-reviews lionss pthread)

add_executable(CustomsHs src/CustomsHs.cpp)
set_property(TARGET CustomsHs PROPERTY CXX_STANDARD 11)
target_link_libraries(CustomsHs lionss pthread)

add_executable(addr_validate src/addr_validate.cpp)
set_property(TARGET addr_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(addr_validate lionss pthread)

add_executable(pwa-shell src/pwa-shell.cpp)
set_property(TARGET pwa-shell PROPERTY CXX_STANDARD 11)
target_link_libraries(pwa-shell lionss pthread)

add_executable(WebhookRetry src/WebhookRetry.cpp)
set_property(TARGET WebhookRetry PROPERTY CXX_STANDARD 11)
target_link_libraries(WebhookRetry lionss pthread)

add_executable(ocsp-stapler src/ocsp-stapler.cpp)
set_property(TARGET ocsp-stapler PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-stapler lionss pthread)

add_executable(otaDelta src/otaDelta.cpp)
set_property(TARGET otaDelta PROPERTY CXX_STANDARD 11)
target_link_libraries(otaDelta lionss pthread)

add_executable(monorepo-affected src/monorepo-affected.cpp)
set_property(TARGET monorepo-affected PROPERTY CXX_STANDARD 11)
target_link_libraries(monorepo-affected lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(bridge_wind_load src/bridge_wind_load.cpp)
set_property(TARGET bridge_wind_load PROPERTY CXX_STANDARD 11)
target_link_libraries(bridge_wind_load lionss pthread)

add_executable(fsck-replay src/fsck-replay.cpp)
set_property(TARGET fsck-replay PROPERTY CXX_STANDARD 11)
target_link_libraries(fsck-replay lionss pthread)

add_executable(license-scan src/license-scan.cpp)
set_property(TARGET license-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(license-scan lionss pthread)

add_executable(ami-reader src/ami-reader.cpp)
set_property(TARGET ami-reader PROPERTY CXX_STANDARD 11)
target_link_libraries(ami-reader lionss pthread)

add_executable(ratecardsync src/ratecardsync.cpp)
set_property(TARGET ratecardsync PROPERTY CXX_STANDARD 11)
target_link_libraries(ratecardsync lionss pthread)

add_executable(turbine_yaw src/turbine_yaw.cpp)
set_property(TARGET turbine_yaw PROPERTY CXX_STANDARD 11)
target_link_libraries(turbine_yaw lionss pthread)

add_executable(bikesharerebal src/bikesharerebal.cpp)
set_property(TARGET bikesharerebal PROPERTY CXX_STANDARD 11)
target_link_libraries(bikesharerebal lionss pthread)

add_executable(raid_rebuild src/raid_rebuild.cpp)
set_property(TARGET raid_rebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(raid_rebuild lionss pthread)

add_executable(ursa src/ursa.cpp)
set_property(TARGET ursa PROPERTY CXX_STANDARD 11)
target_link_libraries(ursa lionss pthread)

add_executable(tz_recalc src/tz_recalc.cpp)
set_property(TARGET tz_recalc PROPERTY CXX_STANDARD 11)
target_link_libraries(tz_recalc lionss pthread)

add_executable(willow-x src/willow-x.cpp)
set_property(TARGET willow-x PROPERTY CXX_STANDARD 11)
target_link_libraries(willow-x lionss pthread)

add_executable(pumice src/pumice.cpp)
set_property(TARGET pumice PROPERTY CXX_STANDARD 11)
target_link_libraries(pumice lionss pthread)

